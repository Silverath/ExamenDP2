
package forms;

public class SearchForm {

	private String	keyword;


	public String getKeyword() {
		return this.keyword;
	}
	public void setKeyword(final String keyword) {
		this.keyword = keyword;
	}
}
